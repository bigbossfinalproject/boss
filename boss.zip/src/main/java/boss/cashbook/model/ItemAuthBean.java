package boss.cashbook.model;

public class ItemAuthBean {
	private int item_group;
	private int root_idn;
	private String item_list;
	
	public int getItem_group() {
		return item_group;
	}
	public void setItem_group(int item_group) {
		this.item_group = item_group;
	}
	public int getRoot_idn() {
		return root_idn;
	}
	public void setRoot_idn(int root_idn) {
		this.root_idn = root_idn;
	}
	public String getItem_list() {
		return item_list;
	}
	public void setItem_list(String item_list) {
		this.item_list = item_list;
	}
	
}
