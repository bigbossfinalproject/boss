package boss.cashbook.model;

public class ObjectRootBean {
	private int root_idn;
	private String root_name;
	private String root_id;
	private String root_password;
	private String root_email;
	private String root_birth;
	private String root_gender;
	private String root_job;
	private String root_address;
	private int root_grade;
	
	public int getRoot_idn() {
		return root_idn;
	}
	public void setRoot_idn(int root_idn) {
		this.root_idn = root_idn;
	}
	public String getRoot_name() {
		return root_name;
	}
	public void setRoot_name(String root_name) {
		this.root_name = root_name;
	}
	public String getRoot_id() {
		return root_id;
	}
	public void setRoot_id(String root_id) {
		this.root_id = root_id;
	}
	public String getRoot_password() {
		return root_password;
	}
	public void setRoot_password(String root_password) {
		this.root_password = root_password;
	}
	public String getRoot_email() {
		return root_email;
	}
	public void setRoot_email(String root_email) {
		this.root_email = root_email;
	}
	public String getRoot_birth() {
		return root_birth;
	}
	public void setRoot_birth(String root_birth) {
		this.root_birth = root_birth;
	}
	public String getRoot_gender() {
		return root_gender;
	}
	public void setRoot_gender(String root_gender) {
		this.root_gender = root_gender;
	}
	public String getRoot_job() {
		return root_job;
	}
	public void setRoot_job(String root_job) {
		this.root_job = root_job;
	}
	public String getRoot_address() {
		return root_address;
	}
	public void setRoot_address(String root_address) {
		this.root_address = root_address;
	}
	public int getRoot_grade() {
		return root_grade;
	}
	public void setRoot_grade(int root_grade) {
		this.root_grade = root_grade;
	}
	
}
