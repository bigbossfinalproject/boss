package boss.cashbook.model;

public class CardCorpBean {
	private String card_corp_code;
	private String card_corp_name;
	private String card_expense_date;
	private String card_use_term;
	
	public String getCard_corp_code() {
		return card_corp_code;
	}
	public void setCard_corp_code(String card_corp_code) {
		this.card_corp_code = card_corp_code;
	}
	public String getCard_corp_name() {
		return card_corp_name;
	}
	public void setCard_corp_name(String card_corp_name) {
		this.card_corp_name = card_corp_name;
	}
	public String getCard_expense_date() {
		return card_expense_date;
	}
	public void setCard_expense_date(String card_expense_date) {
		this.card_expense_date = card_expense_date;
	}
	public String getCard_use_term() {
		return card_use_term;
	}
	public void setCard_use_term(String card_use_term) {
		this.card_use_term = card_use_term;
	}
	
}
